package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

public class TestNota {

	@Test
	public void queExistaUnaNota() {
	Integer dniEsperado=46195259;
	Nota nota = new Nota(46195259,14,7);
		
	assertNotNull(nota);
	assertEquals(dniEsperado, nota.getDniAlumno());
	}
	
	
	@Test
	public void queSePuedaPromocionar() {
	String nombre="Unlam";
	Integer dniAlumno=46195259;
	LocalDate fNaci=LocalDate.of(2004, 11, 05);
	LocalDate fIngreso=LocalDate.of(2023, 02, 01);
	Boolean flag=false;
	
	Universidad uni = new Universidad(nombre);
	Materia materia = new Materia(15,"Mate");
	Alumno alumno = new Alumno(dniAlumno,"sofia","rodriguez",fNaci,fIngreso);
	Nota nota = new Nota(dniAlumno,14,7);
	nota.AsignarNotaMateriaSegundoParcial(6);
	nota.AsignarNotaMateriaSegundoRecu(7);
	flag=nota.promociono();
	
	assertNotNull(uni);
	assertNotNull(materia);
	assertNotNull(alumno);
	assertNotNull(nota);
	assertTrue(flag);
	
	}
	
	
	@Test
	public void queSePuedaAprobarConPendienteFinal() {
	String nombre="Unlam";
	Integer dniAlumno=46195259;
	LocalDate fNaci=LocalDate.of(2004, 11, 05);
	LocalDate fIngreso=LocalDate.of(2023, 02, 01);
	Boolean flag=false;
	
	Universidad uni = new Universidad(nombre);
	Materia materia = new Materia(15,"Mate");
	Alumno alumno = new Alumno(dniAlumno,"sofia","rodriguez",fNaci,fIngreso);
	Nota nota = new Nota(dniAlumno,14,5);
	nota.AsignarNotaMateriaSegundoParcial(5);
	nota.AsignarNotaMateriaSegundoRecu(7);
	flag=nota.aproboPendienteFinal();
	
	assertNotNull(uni);
	assertNotNull(materia);
	assertNotNull(alumno);
	assertNotNull(nota);
	assertTrue(flag);
	
	}
	
	@Test
	public void queSePuedaAprobarConFinal() {
	String nombre="Unlam";
	Integer dniAlumno=46195259;
	LocalDate fNaci=LocalDate.of(2004, 11, 05);
	LocalDate fIngreso=LocalDate.of(2023, 02, 01);
	Boolean flag=false;
	
	Universidad uni = new Universidad(nombre);
	Materia materia = new Materia(15,"Mate");
	Alumno alumno = new Alumno(dniAlumno,"sofia","rodriguez",fNaci,fIngreso);
	Nota nota = new Nota(dniAlumno,14,5);
	nota.AsignarNotaMateriaSegundoParcial(5);
	nota.AsignarNotaMateriaSegundoRecu(7);
	nota.AsignarNotaFinal(4);
	flag=nota.aproboConFinal();
	
	assertNotNull(uni);
	assertNotNull(materia);
	assertNotNull(alumno);
	assertNotNull(nota);
	assertTrue(flag);
	
	}
	
	
	@Test
	public void queSePuedaDesaprobar() {
	String nombre="Unlam";
	Integer dniAlumno=46195259;
	LocalDate fNaci=LocalDate.of(2004, 11, 05);
	LocalDate fIngreso=LocalDate.of(2023, 02, 01);
	Boolean flag=false;
	
	Universidad uni = new Universidad(nombre);
	Materia materia = new Materia(15,"Mate");
	Alumno alumno = new Alumno(dniAlumno,"sofia","rodriguez",fNaci,fIngreso);
	Nota nota = new Nota(dniAlumno,14,5);
	nota.AsignarNotaMateriaSegundoParcial(5);
	nota.AsignarNotaMateriaSegundoRecu(2);
	nota.AsignarNotaFinal(4);
	flag=nota.desaprobo();
	
	assertNotNull(uni);
	assertNotNull(materia);
	assertNotNull(alumno);
	assertNotNull(nota);
	assertTrue(flag);
	
	}
	
	
	
	
	

}
