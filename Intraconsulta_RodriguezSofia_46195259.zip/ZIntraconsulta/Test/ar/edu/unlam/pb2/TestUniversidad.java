package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

public class TestUniversidad {
	
	//
	//ACLARACION:
	//Los printl en los metodos de las clases lo cree para que sea mas facil entender
	//el codigo por si tenia algun error y para saber si los testeos pasaban por la prueba que
	//queria realizar.
	//
	//En los test de los reportes de materias aparecen println de la clase "NOTA"
	//

	@Test
	public void queSePuedaCrearUnaUniversidad() {
		String nombre="Unlam";
		Universidad uni = new Universidad(nombre);
		assertNotNull(uni);
		}
	
	@Test
	public void queSePuedaCrearUnaMateria() {
		Integer valorEsperado=23,id=23;
		Materia nueva = new Materia(id,"matematica");
		assertNotNull(nueva);
		assertEquals(valorEsperado, nueva.getId());
	}
	
	@Test
	public void queNoSePuedaCrearUnaMateriaConElMismoIdyConUnNumeroMenorACero() {
		Universidad uni = new Universidad("Unlam");
		Integer valorEsperado=23,id1=23,id2=45,id3=-5;
		Boolean nueva1,nueva2;
		String nombre="Mate";
		
		nueva1=uni.agregarMateria(id1, nombre);
		nueva2=uni.agregarMateria(id2, nombre);
		
		assertNotNull(nueva1);
		assertNotNull(nueva2);
		assertNotEquals(valorEsperado, uni.agregarMateria(id1, nombre));
		assertNotEquals(valorEsperado, uni.agregarMateria(id3, nombre));
	}
	
	
	@Test
	public void queSePuedaAgregarUnAlumnoConDiferenteDni() {
		Universidad uni = new Universidad("Unlam");
		assertNotNull(uni);
		
		Integer dni1=2463892,dni2=5678,dniEsperado=2463892;
		String nombre="sofia",apellido="rodriguez";
		Boolean alumno1=false, alumno2=false;
		LocalDate fNaci=LocalDate.of(2004, 11, 05);
		LocalDate fIngreso=LocalDate.of(2023, 02, 01);
		
		alumno1=uni.agregarAlumno(dni1, nombre, apellido, fNaci, fIngreso);
		alumno2=uni.agregarAlumno(dni2, nombre, apellido, fNaci, fIngreso);

		
		assertNotNull(alumno1);
		assertNotNull(alumno2);
		assertNotEquals(dniEsperado,uni.agregarAlumno(dni1, nombre, apellido, fNaci, fIngreso));
		
		}
	
	
	@Test
	public void queSePuedaCrearUnCicloLectivo() {
		//QUE NO SE REPITA EL ID Y QUE NO SE SUPERPONGAN LAS FECHAS
		Universidad uni = new Universidad("Unlam");
		assertNotNull(uni);
		
		Boolean nuevo1,nuevo2;
		Integer id1=1, id2=2, id3=3;
		LocalDate fechaInicioInscrpcion = LocalDate.of(2023, 02, 01);
		LocalDate fechaFinInscripcion = LocalDate.of(2023, 02, 28);
		LocalDate fechaInicio = LocalDate.of(2023, 04, 01);
		LocalDate fechaFin = LocalDate.of(2023, 11, 30);
		LocalDate fechaTemporal = LocalDate.of(2022,07,29);
		
		nuevo1=uni.crearCicloLectivo(id1, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion);
		nuevo2=uni.crearCicloLectivo(id2, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion);
		
		
		assertNotNull(nuevo1);
		assertNotNull(nuevo2);
		assertNotEquals(id1, uni.crearCicloLectivo(id1, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion));
		assertNotEquals(id3, uni.crearCicloLectivo(id3, fechaInicio, fechaTemporal, fechaInicioInscrpcion, fechaFinInscripcion));
		
	}
	
	@Test
	public void queSePuedaAgregarUnaComision() {
		//QUE NO SE REPITA EL ID. 
		//QUE NO HAYA COMISION EL MISMO DIA,TURNO,CICLO Y MATERIA.
		//QUE EL ID NO SEA MENOR A CERO.
		Universidad uni = new Universidad("Unlam");
		assertNotNull(uni);
		
		Boolean comision1,comision2,comision3,comision4,comision5;
		Integer idComision1=1,idComision2=2,idComision3=3,idComision4=-3;
		String materia1="Programacion";
		Integer idCiclo1=1,idCiclo2=2,idCiclo3=3;
		Integer idAula1=1;
		String turno1="mañana",turno2="tarde",turno3="noche";
		String dia1="lunes",dia2="martes",dia3="miercoles";
		Integer capacidad1=100;
		Integer inscriptos1=87;
		Integer dniProfe=12345;
		
		comision1=uni.crearComision(idComision1, materia1, idCiclo1, idAula1, turno1, dia1, capacidad1, inscriptos1, dniProfe);
		comision2=uni.crearComision(idComision2, materia1, idCiclo2, idAula1, turno2, dia2, capacidad1, inscriptos1, dniProfe);
		comision3=uni.crearComision(idCiclo1, materia1, idCiclo3, idAula1, turno3, dia3, capacidad1, inscriptos1, dniProfe);
		comision4=uni.crearComision(idComision3, materia1, idCiclo1, idAula1, turno1, dia1, capacidad1, inscriptos1, dniProfe);
		comision5=uni.crearComision(idComision4, materia1, idCiclo3, idAula1, turno3, dia2, capacidad1, inscriptos1, dniProfe);
		
		
		assertNotNull(comision1);
		assertNotNull(comision2);
		assertNotNull(comision3);
		assertNotNull(comision4);
		assertNotNull(comision5);
		
		}
	
	@Test
	public void queSePuedaCrearUnDocente() {
		Universidad uni = new Universidad("Unlam");
		assertNotNull(uni);
		
		Integer dni1=2463892;
		Integer dni2=5678;
		Boolean test=false, test2=false,test3=false;
		
		test=uni.crearDocente("diego", "null", dni1);
		test2=uni.crearDocente("diego", "null", dni2);
		test3=uni.crearDocente("diego", "null", dni1);
		
		assertNotNull(test);
		assertNotNull(test2);
		assertNotNull(test3);
		
		}
	
	
	
	@Test
	public void queSePuedaAsignarMateriaCorrelativa() {
		Universidad uni = new Universidad("Unlam");
		
		Integer id1=23,id2=25,id3=56;
		Boolean mate1=false, mate2=false;
		
		mate1 = uni.agregarMateria(id1, "mate1");
		mate2 = uni.agregarMateria(id2, "mate2");

		assertNotNull(mate1);
		assertNotNull(mate2);
		assertTrue(uni.AsiganarMateriaCorrelativa(id1, id2));
		assertFalse(uni.AsiganarMateriaCorrelativa(id1, id3));
		
		}
	
	@Test
	public void queSePuedaEliminarMateriaCorrelativa() {
		Universidad uni = new Universidad("Unlam");
		
		Integer id1=23,id2=25,id3=56;
		Boolean mate1=false, mate2=false;
		
		mate1 = uni.agregarMateria(id1, "mate1");
		mate2 = uni.agregarMateria(id2, "mate2");

		assertNotNull(mate1);
		assertNotNull(mate2);
		assertTrue(uni.AsiganarMateriaCorrelativa(id1, id2));
		assertTrue(uni.eliminarCorrelativa(id1, id2));
		assertFalse(uni.eliminarCorrelativa(id1, id3));
		
		}
	
	@Test
	public void queSePuedaIncribirAUnAlumnoAComision() {
		//Y TODAS LAS RESTRICCIONES DEL METODO.
		//Y QUE SE PUEDAN CREAN LAS NOTAS(PRIMER PARCIAL, SEGUNDO, RECUPERATORIOS Y FINALES).
		Universidad uni = new Universidad("Unlam");
		LocalDate fNaci=LocalDate.of(2004, 11, 05);
		LocalDate fIngreso=LocalDate.of(2023, 02, 01);
		LocalDate fechaInicioInscrpcion = LocalDate.of(2023, 9, 25);
		LocalDate fechaFinInscripcion = LocalDate.of(2023, 9, 30);
		LocalDate fechaInicio = LocalDate.of(2023, 10, 01);
		LocalDate fechaFin = LocalDate.of(2023, 11, 30);
		Integer idMateria1=1,idmateria2=2,idMateria3=3,idMateria4=4;
		Integer dniAlumno1=12345,dniAlumno2=54321;
		Integer idComision1=25,idComision2=30,idComision3=35,idComision4=40;
		
		
		Integer idCiclo1=1;
		Integer idAula1=1,idAula2=2,idAula3=3;
		String turno1="mañana",turno2="tarde",turno3="noche";
		String dia1="lunes",dia2="martes",dia3="miercoles";
		Integer capacidad=100;
		Integer inscriptos=87;
		Integer dniProfe=123456;
		
		
		Boolean flag=false,variable=false,cubo=false,cicloLectivo=false,materia1=false,materia2=false,materia3=false,materia4=false,alumno1=false,alumno2=false,comision1=false,comision2=false,comision3=false,comision4=false;
		
		
		
		cicloLectivo = uni.crearCicloLectivo(idCiclo1, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion);
		materia1 = uni.agregarMateria(idMateria1,"Programacion");
		materia2 = uni.agregarMateria(idmateria2, "Programacion2");
		materia3 = uni.agregarMateria(idMateria3, "Programacion3");
		materia4 = uni.agregarMateria(idMateria4, "Programacion4");
		alumno1 = uni.agregarAlumno(dniAlumno1,"sofia","rodriguez",fNaci,fIngreso);
		alumno2 = uni.agregarAlumno(dniAlumno2,"sofia","rodriguez",fNaci,fIngreso);
		comision1 = uni.crearComision(idComision1,"Programacion",idCiclo1,idAula1,turno1,dia1,capacidad,inscriptos,dniProfe);
		comision2 = uni.crearComision(idComision2,"Programacion2",idCiclo1,idAula2,turno1,dia2,capacidad,inscriptos,dniProfe);
		comision3 = uni.crearComision(idComision3, "Programacion3", idCiclo1, idAula3, turno3, dia1, capacidad, inscriptos, dniProfe);
		comision4 = uni.crearComision(idComision4, "Programacion4", idCiclo1, idAula3, turno1, dia1, capacidad, inscriptos, dniProfe);
		
		flag=uni.InscribirAlumnoAComision(dniAlumno1, idComision1);
		variable = uni.AsiganarMateriaCorrelativa(idmateria2, idMateria1);
		variable = uni.crearNotaPrimerParcial(dniAlumno1, idMateria1, 7);
		variable = uni.crearNotaSegundoParcial(dniAlumno1, idMateria1, 7);
		
		variable = uni.InscribirAlumnoAComision(dniAlumno1, idComision2);
		cubo = uni.InscribirAlumnoAComision(dniAlumno1, idComision4);
		assertTrue(flag);
		assertTrue(variable);
		assertFalse(cubo);
		
	}
	
	
	@Test 
	public void queSePuedanObtenerListadoMateriasAprobadas() {
		Universidad uni = new Universidad("Unlam");
		LocalDate fNaci=LocalDate.of(2004, 11, 05);
		LocalDate fIngreso=LocalDate.of(2023, 02, 01);
		LocalDate fechaInicioInscrpcion = LocalDate.of(2023, 9, 25);
		LocalDate fechaFinInscripcion = LocalDate.of(2023, 9, 30);
		LocalDate fechaInicio = LocalDate.of(2023, 10, 01);
		LocalDate fechaFin = LocalDate.of(2023, 11, 30);
		Integer idMateria1=1,idmateria2=2,idMateria3=3,idMateria4=4;
		Integer dniAlumno1=12345,dniAlumno2=54321;
		Integer idComision1=25,idComision2=30,idComision3=35,idComision4=40;
		
		
		Integer idCiclo1=1;
		Integer idAula1=1,idAula2=2,idAula3=3;
		String turno1="mañana",turno2="tarde",turno3="noche";
		String dia1="lunes",dia2="martes",dia3="miercoles";
		Integer capacidad=100;
		Integer inscriptos=87;
		Integer dniProfe=123456;
		
		
		Boolean flag=false,variable=false,cubo=false,cicloLectivo=false,materia1=false,materia2=false,materia3=false,materia4=false,alumno1=false,alumno2=false,comision1=false,comision2=false,comision3=false,comision4=false;
		
		
		
		cicloLectivo = uni.crearCicloLectivo(idCiclo1, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion);
		materia1 = uni.agregarMateria(idMateria1,"Programacion");
		materia2 = uni.agregarMateria(idmateria2, "Programacion2");
		materia3 = uni.agregarMateria(idMateria3, "Programacion3");
		materia4 = uni.agregarMateria(idMateria4, "Programacion4");
		alumno1 = uni.agregarAlumno(dniAlumno1,"sofia","rodriguez",fNaci,fIngreso);
		alumno2 = uni.agregarAlumno(dniAlumno2,"sofia","rodriguez",fNaci,fIngreso);
		comision1 = uni.crearComision(idComision1,"Programacion",idCiclo1,idAula1,turno1,dia1,capacidad,inscriptos,dniProfe);
		comision2 = uni.crearComision(idComision2,"Programacion2",idCiclo1,idAula2,turno1,dia2,capacidad,inscriptos,dniProfe);
		comision3 = uni.crearComision(idComision3, "Programacion3", idCiclo1, idAula3, turno3, dia1, capacidad, inscriptos, dniProfe);
		comision4 = uni.crearComision(idComision4, "Programacion4", idCiclo1, idAula3, turno1, dia1, capacidad, inscriptos, dniProfe);
		
		variable = uni.crearNotaPrimerParcial(dniAlumno1, idMateria1, 7);
		variable = uni.crearNotaSegundoParcial(dniAlumno1, idMateria1, 4);
		variable = uni.obtenerListadoMateriasAprobadas(dniAlumno1);
		
		
	}
	
	
	@Test 
	public void queSePuedanObtenerListadoMateriasQueLeFaltanCursar() {
		Universidad uni = new Universidad("Unlam");
		LocalDate fNaci=LocalDate.of(2004, 11, 05);
		LocalDate fIngreso=LocalDate.of(2023, 02, 01);
		LocalDate fechaInicioInscrpcion = LocalDate.of(2023, 9, 25);
		LocalDate fechaFinInscripcion = LocalDate.of(2023, 9, 30);
		LocalDate fechaInicio = LocalDate.of(2023, 10, 01);
		LocalDate fechaFin = LocalDate.of(2023, 11, 30);
		Integer idMateria1=1,idMateria2=2,idMateria3=3,idMateria4=4;
		Integer dniAlumno1=12345,dniAlumno2=54321;
		Integer idComision1=25,idComision2=30,idComision3=35,idComision4=40;
		
		
		Integer idCiclo1=1;
		Integer idAula1=1,idAula2=2,idAula3=3;
		String turno1="mañana",turno2="tarde",turno3="noche";
		String dia1="lunes",dia2="martes",dia3="miercoles";
		Integer capacidad=100;
		Integer inscriptos=87;
		Integer dniProfe=123456;
		
		
		Boolean flag=false,variable=false,cubo=false,cicloLectivo=false,materia1=false,materia2=false,materia3=false,materia4=false,alumno1=false,alumno2=false,comision1=false,comision2=false,comision3=false,comision4=false;
		
		
		
		cicloLectivo = uni.crearCicloLectivo(idCiclo1, fechaInicio, fechaFin, fechaInicioInscrpcion, fechaFinInscripcion);
		materia1 = uni.agregarMateria(idMateria1,"Programacion");
		materia2 = uni.agregarMateria(idMateria2, "Programacion2");
		materia3 = uni.agregarMateria(idMateria3, "Programacion3");
		materia4 = uni.agregarMateria(idMateria4, "Programacion4");
		alumno1 = uni.agregarAlumno(dniAlumno1,"sofia","rodriguez",fNaci,fIngreso);
		alumno2 = uni.agregarAlumno(dniAlumno2,"sofia","rodriguez",fNaci,fIngreso);
		comision1 = uni.crearComision(idComision1,"Programacion",idCiclo1,idAula1,turno1,dia1,capacidad,inscriptos,dniProfe);
		comision2 = uni.crearComision(idComision2,"Programacion2",idCiclo1,idAula2,turno1,dia2,capacidad,inscriptos,dniProfe);
		comision3 = uni.crearComision(idComision3, "Programacion3", idCiclo1, idAula3, turno3, dia1, capacidad, inscriptos, dniProfe);
		comision4 = uni.crearComision(idComision4, "Programacion4", idCiclo1, idAula3, turno1, dia1, capacidad, inscriptos, dniProfe);
		
		variable = uni.crearNotaPrimerParcial(dniAlumno1, idMateria1, 7);
		variable = uni.crearNotaSegundoParcial(dniAlumno1, idMateria1, 7);
		uni.obtenerMateriasQueFaltanCursar(dniAlumno1);
		
		
		flag = uni.crearNotaPrimerParcial(dniAlumno2, idMateria1, 8);
		flag = uni.crearNotaSegundoParcial(dniAlumno2, idMateria1, 3);
		flag = uni.crearNotaSegundoRecuperatorio(dniAlumno2, idMateria1, 9);
		uni.obtenerMateriasQueFaltanCursar(dniAlumno2);
		
		
		//REPORTE DE LAS NOTAS DE LOS ALUMNOS(ULTIMO METODO)
		uni.ObtenerReporteDeNotasDeAumnosPorComision(idComision1);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
