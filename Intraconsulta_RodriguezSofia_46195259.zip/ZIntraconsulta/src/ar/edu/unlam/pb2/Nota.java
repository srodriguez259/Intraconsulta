package ar.edu.unlam.pb2;

public class Nota {
	
	//ATRIBUTOS:
	private Integer valorPrimerParcial;
	private Integer valorSegundoParcial;
	private Integer valorPrimerRecuperatorio;
	private Integer valorSegundoRecuperatorio;
	private Integer finalMateria;
	private Integer idMateria;
	private Integer dniAlumno;
	
	
	//CONSTRUCTOR:
	public Nota(Integer dniAlumno, Integer idMateria, Integer valorPrimerParcial) {
		this.dniAlumno=dniAlumno;
		this.idMateria=idMateria;
		this.valorPrimerParcial=valorPrimerParcial;
		this.valorSegundoParcial=0;
		this.valorPrimerRecuperatorio=0;
		this.valorSegundoRecuperatorio=0;
		this.finalMateria=0;
	}
	
	
	//METODOS:
	public Boolean promociono() {
		if((this.valorPrimerParcial>=7 || this.valorPrimerRecuperatorio>=7) &&
				(this.valorSegundoParcial>=7 || this.valorSegundoRecuperatorio>=7)){
			System.out.println("Promociono");
			return true;
		}
		return false;
	}
	
	public Boolean aproboPendienteFinal (){
		Integer auxiliar1=0,auxiliar2=0;
		if(this.valorPrimerRecuperatorio>0) {
			auxiliar1=this.valorPrimerRecuperatorio;
		}else {
			auxiliar1=this.valorPrimerParcial;
		}
		if(this.valorSegundoRecuperatorio>0) {
			auxiliar2=this.valorSegundoRecuperatorio;
		}else {
			auxiliar2=this.valorSegundoParcial;
		}
		
		if((auxiliar1>=4 && auxiliar2>=4) && (auxiliar1<=6 || auxiliar2<=6) && this.finalMateria<4) {
			System.out.println("Esta pendiente de final");
			return true;
		}
		return false;
	}
	
	
	public Boolean aproboConFinal (){
		if(this.finalMateria>=4) {
			System.out.println("Aprobo con final");
			return true;
		}
		return false;
	}
	
	public Boolean desaprobo (){
		Integer auxiliar1=0,auxiliar2=0;
		if(this.valorPrimerRecuperatorio>0) {
			auxiliar1=this.valorPrimerRecuperatorio;
		}
		if(this.valorSegundoRecuperatorio>0) {
			auxiliar2=this.valorSegundoRecuperatorio;
		}
		if(auxiliar1<4 || auxiliar2<4) {
			System.out.println("Recursa");
			return true;
		}
		return false;
	}

	public Integer getNotaFinal() {
		Integer notaFinal=0;
		if(this.aproboConFinal()) {
			notaFinal=this.finalMateria;
		}
		if(this.promociono()) {
			notaFinal=((int)(this.valorPrimerParcial + this.valorSegundoParcial)/2);
		}
		return notaFinal;
	}
	

	public Integer getFinalMateria() {
		return finalMateria;
	}


	public Integer getIdMateria() {
		return idMateria;
	}


	public Integer getDniAlumno() {
		return dniAlumno;
	}
	
	
	public Integer AsignarNotaMateriaPrimerParcial (Integer valorNota) {
		return this.valorPrimerParcial=valorNota;
	}	
	
	public Integer AsignarNotaMateriaSegundoParcial (Integer valorNota) {
		return this.valorSegundoParcial=valorNota;
	}
	
	public Integer AsignarNotaMateriaPrimerRecu (Integer valorNota) {
		return this.valorPrimerRecuperatorio=valorNota;
	}
	
	public Integer AsignarNotaMateriaSegundoRecu (Integer valorNota) {
		return this.valorSegundoRecuperatorio=valorNota;
	}
	
	public Integer AsignarNotaFinal(Integer valorNota) {
		return this.finalMateria=valorNota;
	}
	
	
	
	
}
