package ar.edu.unlam.pb2;

public class InscripcionMateria {

	private Integer idComision;
	private Integer dniAlumno;
	
	
	public InscripcionMateria(Integer idComision,Integer dniAlumno) {
		this.idComision=idComision;
		this.dniAlumno=dniAlumno;
	}


	public Integer getIdComision() {
		return idComision;
	}

	public Integer getDniAlumno() {
		return dniAlumno;
	}
	
	
		
		
	
	
}
