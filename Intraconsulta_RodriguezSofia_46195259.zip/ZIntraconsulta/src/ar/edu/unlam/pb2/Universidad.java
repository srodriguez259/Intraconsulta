package ar.edu.unlam.pb2;

import java.time.LocalDate;

import java.util.ArrayList;

public class Universidad {

	private String nombre;
	private ArrayList<Alumno> alumnos;
	private ArrayList<Materia> materias;
	private ArrayList<CicloLectivo> cicloLectivo;
	private ArrayList<Comision> comision;
	private ArrayList<Docente> docente;
	private ArrayList<Nota> notas;
	private ArrayList <InscripcionMateria> inscripcionesMateria;
	
	
	public Universidad(String nombre) {
		this.nombre = nombre;
		this.alumnos = new ArrayList<Alumno>();
		this.materias = new ArrayList<Materia>();
		this.cicloLectivo = new ArrayList<CicloLectivo>();
		this.comision = new ArrayList<Comision>();
		this.docente = new ArrayList<Docente>();
		this.notas = new ArrayList<Nota>();
		this.inscripcionesMateria = new ArrayList<InscripcionMateria>();
	}
	
	
	public Boolean agregarMateria(Integer id, String nombreMateria) {
		Materia materia;
		for(int i =0; i<this.materias.size();i++) {
			if (this.materias.get(i).getId()==id) {
				System.out.println("Tiene el mismo Id");
				return false;
			}
		}
		if(id>0) {
			materia = new Materia(id,nombreMateria);
			this.materias.add(materia);
			System.out.println("Se agrego correctamente");
			return true;
		}
		return false;
	}
	
	
	public Boolean agregarAlumno(Integer dniAlumno,String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso) {
		Alumno alumno;
		for(int i =0;i<this.alumnos.size();i++) {
			if(dniAlumno==this.alumnos.get(i).getDni()) {
				System.out.println("ya se agrego un Alumno con el mismo DNI");
				return false;
			}
		}
		
		alumno = new Alumno(dniAlumno,nombre,apellido,fechaNacimiento,fechaIngreso);
		this.alumnos.add(alumno);
		System.out.println("Agregado correctamente");
		return true;
	}
	
	
	public Boolean crearCicloLectivo(Integer id, LocalDate fechaInicio, LocalDate fechaFinalizacion,LocalDate fechaInicioInscripcion, LocalDate fechaFinalizacionInscripcion) {
		CicloLectivo cicloLectivo;
		for(int i=0;i<this.cicloLectivo.size();i++) {
			if(id==this.cicloLectivo.get(i).getId()) {
				System.out.println("Ya existe una comision con ese ID");
				return false;
			}
		}
		
		if(id>0 && fechaInicioInscripcion.isBefore(fechaFinalizacionInscripcion)&& fechaFinalizacionInscripcion.isBefore(fechaInicio)&& fechaInicio.isBefore(fechaFinalizacion)) {
			cicloLectivo = new CicloLectivo(id,fechaInicio,fechaFinalizacion,fechaInicioInscripcion,fechaFinalizacionInscripcion);
			this.cicloLectivo.add(cicloLectivo);
			System.out.println("Creado correctamente");
			return true;
		}
		
		System.out.println("El id es menor a cero o estan mal ingresadas las fechas");
		return false;
	}
	
	
	public Boolean crearComision(Integer id, String materia, Integer idCicloLectivo, Integer idAula, String turno, String dia, Integer capacidad,Integer cantidadInscriptos, Integer dniProfesor) {
		Comision comision;
		for(int i=0;i<this.comision.size();i++) {
			if(id==this.comision.get(i).getIdComision()) {
				System.out.println("Ya existe una comision con este ID");
				return false;
			}
		}
		
		for(int i=0;i<this.comision.size();i++) {
			if(this.comision.get(i).getMateria()==materia && this.comision.get(i).getIdCicloLectivo()==idCicloLectivo && this.comision.get(i).getTurno()==turno && this.comision.get(i).getDia()==dia){
				System.out.println("Ya hay una comision con esa materia, ciclo lectivo, turno y dia");
				return false;
				}
			}
		
		if(id>0) {
			comision = new Comision(id,materia,idCicloLectivo,idAula,turno,dia,capacidad,cantidadInscriptos,dniProfesor);
			this.comision.add(comision);
			System.out.println("Se agrego correctamente");
			return true;
		}
		
		System.out.println("El ID es menor a cero");
		return false;
	}
	
	
	public Boolean crearDocente(String nombre, String apellido, Integer dni) {
		Docente docente;
		for(int i=0;i<this.docente.size();i++) {
			if(dni==this.docente.get(i).getDni()) {	
				System.out.println("Ya existe un docente con ese DNI");
				return false;
			}
		}
		
		docente = new Docente(nombre,apellido,dni);
		this.docente.add(docente);
		System.out.println("Agregado correctamente");
		return true;
	}
	
	
	public Boolean AsiganarMateriaCorrelativa (Integer idMateria, Integer idDeMateriaCorrelativa) {
		Materia materia;
		if (idMateria == idDeMateriaCorrelativa){
			return false;
		}
		for(int i=0;i<this.materias.size();i++) {
			if(idMateria==this.materias.get(i).getId()) {
				//existe el id de la materia
				for(int j=0;j<this.materias.size();j++) {
					if(idDeMateriaCorrelativa==this.materias.get(j).getId()) {
						//existe el id de la correlativa
						materia = this.materias.get(i);
						materia.AsignarMateriaCorrelativa(idDeMateriaCorrelativa);
						this.materias.set(i, materia);
						System.out.println("Se asigno correctamente la correlativa");
						return true;
					}
				}
			}	
		}
		System.out.println("No se agrego la correlativa");
		return false;
	}
	
	
	public Boolean eliminarCorrelativa(Integer idMateria,Integer idMateriaCorrelativaEliminar) {
		Materia materia;
		for(int i=0;i<this.materias.size();i++) {
			if(idMateria==this.materias.get(i).getId()) {
				for(int j=0;j<this.materias.size();j++) {
					if(idMateriaCorrelativaEliminar==this.materias.get(j).getId()) {
						materia = this.materias.get(i);
						materia.eliminarCorrelativa();
						this.materias.set(i, materia);
						System.out.println("Se elimino correctamente");
						return true;
						}	
					}
				}
			}
		System.out.println("No se pudo eliminar la correlativa");
		return false;
	}
	
	
	
	public Boolean InscribirAlumnoAComision (Integer dni, Integer idComision) {
		Boolean existeComision=false,existeAlumno = false;
		for(int i=0;i<this.comision.size();i++) {
			if(this.comision.get(i).getIdComision()==idComision) {
				existeComision = true;
			}
		}
		for(int i=0;i<this.alumnos.size();i++) {
			if(this.alumnos.get(i).getDni()==dni) {
				existeAlumno = true;
			}
		}
		if (existeComision == false || existeAlumno == false) {
			System.out.println("No existe el alumno o la comision");
			return false;
			}
		
		
		for(int i=0;i<this.cicloLectivo.size();i++) {
			if(this.cicloLectivo.get(i).getFechaInicioInscripcion().isAfter(LocalDate.now()) || this.cicloLectivo.get(i).getFechaFinalizacionInscripcion().isBefore(LocalDate.now())) {
				System.out.println("Estas fuera de las fechas de inscripcion");
				return false;
			}
		}
		
		
		for(int i=0;i<this.comision.size();i++) {
			if(this.comision.get(i).getCapacidad()==this.comision.get(i).getCantidadInscriptos()) {
				System.out.println("La comision ya esta completa");
				return false;
			}
		}
		
		
		String dia="", turno="";
		for(int i=0;i<this.comision.size();i++) {
			if(this.comision.get(i).getIdComision()==idComision) {
				dia = this.comision.get(i).getDia();
				turno = this.comision.get(i).getTurno();				
			}
		}
		
		Integer idComisionAlumno=0;
		for(int i=0;i<this.inscripcionesMateria.size();i++) {
			if(this.inscripcionesMateria.get(i).getDniAlumno()==dni) {
				idComisionAlumno=this.inscripcionesMateria.get(i).getIdComision();
				for(int j=0;j<this.comision.size();j++) {
					if(this.comision.get(j).getIdComision()==idComisionAlumno) {
						if(dia==this.comision.get(j).getDia() && turno==this.comision.get(j).getTurno()) {
							System.out.println("Esta anotado en una comision el mismo dia y horario");
							return false;
						}
					}
				}
			}
		}
		
		Integer idCorrelativa=0;
		InscripcionMateria inscripto;
		for(int i=0;i<this.comision.size();i++) {
			if(idComision==this.comision.get(i).getIdComision()) {
				for(int j=0;j<this.materias.size();j++) {
					if(this.materias.get(j).getNombreMateria()==this.comision.get(i).getMateria()) {
						idCorrelativa=this.materias.get(j).getIdCorrelativa();
						if (idCorrelativa > 0 ) {
							for(int k=0;k<this.notas.size();k++) {
								if(this.notas.get(k).getIdMateria()==idCorrelativa && this.notas.get(k).getDniAlumno()==dni) {
									if(this.notas.get(k).aproboConFinal() || this.notas.get(k).promociono() || this.notas.get(k).aproboPendienteFinal()) {
										System.out.println("Se anoto correctamente");
										this.comision.get(i).setAgregarInscripto();
										inscripto=new InscripcionMateria(idComision,dni);
										this.inscripcionesMateria.add(inscripto);
										return true;
									}
								}
							}
						}else {
							System.out.println("Se anoto correctamente porque no tiene correlativas");
							this.comision.get(i).setAgregarInscripto();
							inscripto=new InscripcionMateria(idComision,dni);
							this.inscripcionesMateria.add(inscripto);
							return true;
						}

					}
				}
			}
		}
		System.out.println("No se pudo anotar");
		return false;
		
	}
	
	
	
	
	public Boolean crearNotaPrimerParcial(Integer dniAlumno,Integer idMateria, Integer valorPrimerParcial) {
		Nota nota = new Nota (dniAlumno, idMateria,  valorPrimerParcial);
		this.notas.add(nota);
		return true;
	}
	
	public Boolean crearNotaSegundoParcial(Integer dniAlumno,Integer idMateria, Integer valorSegundoParcial) {
		Nota nota;
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getDniAlumno()==dniAlumno && this.notas.get(i).getIdMateria()==idMateria) {
				nota = this.notas.get(i);
				nota.AsignarNotaMateriaSegundoParcial(valorSegundoParcial);
				this.notas.set(i, nota);
				return true;
			}
		}
		return false;
	}
	
	public Boolean crearNotaPrimerRecuperatorio(Integer dniAlumno,Integer idMateria, Integer valorPrimerRecuperatorio) {
		Nota nota;
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getDniAlumno()==dniAlumno && this.notas.get(i).getIdMateria()==idMateria) {
				nota = this.notas.get(i);
				nota.AsignarNotaMateriaPrimerRecu(valorPrimerRecuperatorio);
				this.notas.set(i, nota);
				return true;
			}
		}
		return false;
	}
	
	public Boolean crearNotaSegundoRecuperatorio(Integer dniAlumno,Integer idMateria, Integer valorSegundoRecuperatorio) {
		Nota nota;
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getDniAlumno()==dniAlumno && this.notas.get(i).getIdMateria()==idMateria) {
				nota = this.notas.get(i);
				nota.AsignarNotaMateriaSegundoRecu(valorSegundoRecuperatorio);
				this.notas.set(i, nota);
				return true;
			}
		}
		return false;
	}
	
	public Boolean crearNotaFinal(Integer dniAlumno,Integer idMateria, Integer valorFinal) {
		Nota nota;
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getDniAlumno()==dniAlumno && this.notas.get(i).getIdMateria()==idMateria) {
				nota = this.notas.get(i);
				nota.AsignarNotaFinal(valorFinal);
				this.notas.set(i, nota);
				return true;
			}
		}
		return false;
	}
	
	
	public Boolean obtenerListadoMateriasAprobadas(Integer dniAlumno) {
		String nombre="",apellido="",nombreMateria="";
		Integer idMateria=0,notaFinal=0;
		
		for(int j=0; j<this.alumnos.size();j++) {
			if(dniAlumno == this.alumnos.get(j).getDni()) {
				nombre=this.alumnos.get(j).getNombre();
				apellido=this.alumnos.get(j).getApellido();
				
			}
		}	
		
		
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getDniAlumno()==dniAlumno) {
				idMateria=this.notas.get(i).getIdMateria();
				for(int j=0; j<this.materias.size();j++) {
					if(this.materias.get(j).getId()==idMateria){
						nombreMateria=this.materias.get(j).getNombreMateria();
					}
				}
				if(this.notas.get(i).promociono() || this.notas.get(i).aproboConFinal()) {
					notaFinal = this.notas.get(i).getNotaFinal();
					System.out.println("DNI: " + dniAlumno + ", NOMBRE Y APELLIDO: " + nombre + " " + apellido + ", NOMBRE MATERIA: " + nombreMateria + ", NOTA FINAL: " + notaFinal );
				}
			}
		}
		return false;
	}
	
	
	public void obtenerMateriasQueFaltanCursar(Integer dniAlumno) {
		String nombreMateria="";
		Integer idMateria=0;
		Boolean encontrado=false;
		System.out.println("materias pendientes para el alumno: " + dniAlumno);
		for(int i=0;i<this.materias.size();i++) {
			nombreMateria=this.materias.get(i).getNombreMateria();
			idMateria = this.materias.get(i).getId();
			encontrado=false;
			for(int j=0;j<this.notas.size();j++) {
				if(this.notas.get(j).getIdMateria()==idMateria && this.notas.get(j).getDniAlumno()==dniAlumno) {
					encontrado=true;
					if(!this.notas.get(j).promociono() && !this.notas.get(j).aproboPendienteFinal() && !this.notas.get(j).aproboConFinal() ) {
						System.out.println("Nombre de la materia que le falta cursar: " + nombreMateria);
					}
				}	
			}
			if(encontrado==false) {
				System.out.println("Nombre de la materia que le falta cursar: " + nombreMateria);
			}
		}
	}
	
	
	
	
	public void ObtenerReporteDeNotasDeAumnosPorComision(Integer idComision){
		String nombreMateria="";
		Integer idMateria=0,dniAlumno=0;
		System.out.println("Notas de la comision: " + idComision);
		for(int i=0;i<this.comision.size();i++) {
			if(this.comision.get(i).getIdComision()==idComision) {
				nombreMateria=this.comision.get(i).getMateria();
				for(int j=0;j<this.materias.size();j++) {
					if(this.materias.get(j).getNombreMateria()==nombreMateria) {
						idMateria=this.materias.get(j).getId();
					}
				}
			}
		}
		for(int i=0;i<this.notas.size();i++) {
			if(this.notas.get(i).getIdMateria()==idMateria) {
				dniAlumno=this.notas.get(i).getDniAlumno();
				System.out.println("Comision: " + idComision  + ", Nombre de la materia: " + nombreMateria + ", DNI del alumno: " + dniAlumno + ", Nota: " + this.notas.get(i).getNotaFinal());
			}
		}
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
