package ar.edu.unlam.pb2;

public class Docente {
	
	//ATRIBUTOS:
	private String nombre;
	private String apellido;
	private Integer dni;
	
	
	//CONSTRUCTOR:
	public Docente(String nombre, String apellido, Integer dni) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
	}


	//METODOS:
	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public Integer getDni() {
		return dni;
	}

}
