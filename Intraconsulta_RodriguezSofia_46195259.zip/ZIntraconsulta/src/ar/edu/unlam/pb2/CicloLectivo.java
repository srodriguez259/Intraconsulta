package ar.edu.unlam.pb2;

import java.time.LocalDate;

public class CicloLectivo {
	
	//ATRIBUTOS:
	private Integer id;
	private LocalDate fechaInicio;
	private LocalDate fechaFinalizacion;
	private LocalDate fechaInicioInscripcion;
	private LocalDate fechaFinalizacionInscripcion;
	

	//CONSTRUCTOR:
	public CicloLectivo(Integer id, LocalDate fechaInicio, LocalDate fechaFinalizacion,LocalDate fechaInicioInscripcion, LocalDate fechaFinalizacionInscripcion) {
		this.id = id;
		this.fechaInicio = fechaInicio;
		this.fechaFinalizacion = fechaFinalizacion;
		this.fechaInicioInscripcion = fechaInicioInscripcion;
		this.fechaFinalizacionInscripcion = fechaFinalizacionInscripcion;
	}

	
	//METODOS:
	public Integer getId() {
		return id;
	}
	
	public LocalDate getFechaInicio() {
		return fechaInicio;
	}

	public LocalDate getFechaFinalizacion() {
		return fechaFinalizacion;
	}

	public LocalDate getFechaInicioInscripcion() {
		return fechaInicioInscripcion;
	}

	public LocalDate getFechaFinalizacionInscripcion() {
		return fechaFinalizacionInscripcion;
	}
}
