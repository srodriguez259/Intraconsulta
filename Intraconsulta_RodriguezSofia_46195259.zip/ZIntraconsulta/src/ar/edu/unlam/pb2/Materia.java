package ar.edu.unlam.pb2;

public class Materia {
	
	//ATRIBUTOS:
	private Integer id;
	private String nombreMateria;
	private Integer idCorrelativa;
	
	
	//CONSTRUCTORES:
	public Materia(Integer id, String nombreMateria, Integer idCorrelativa) {
		this.id = id;
		this.nombreMateria = nombreMateria;
		this.idCorrelativa = idCorrelativa;
	}
	
	public Materia(Integer id, String nombreMateria) {
			this.id = id;
			this.nombreMateria = nombreMateria;
			this.idCorrelativa = 0;
	}

	//METODOS:
	public void AsignarMateriaCorrelativa (Integer idCorrelativa) {
		this.idCorrelativa=idCorrelativa;
	}	
	
	public void eliminarCorrelativa() {
		this.idCorrelativa=0;
	}
	
	public Integer getId() {
		return id;
	}

	public String getNombreMateria() {
		return nombreMateria;
	}
	
	public Integer getIdCorrelativa() {
		return idCorrelativa;
	}	
	
}
