package ar.edu.unlam.pb2;

public class Comision {

	//ATRIBUTOS:
	private Integer idComision;
	private String materia;
	private Integer idCicloLectivo;
	private Integer idAula;
	private String turno; 
	private String dia;
	private Integer capacidad;
	private Integer cantidadInscriptos;
	private Integer dniProfesor;
	
	
	
	//CONSTRUCTOR:
	public Comision(Integer id, String materia, Integer idCicloLectivo, Integer idAula, String turno, String dia, Integer capacidad,Integer cantidadInscriptos, Integer dniProfesor) {
		this.idComision = id;
		this.materia=materia;
		this.idCicloLectivo = idCicloLectivo;
		this.idAula = idAula;
		this.turno = turno;
		this.dia=dia;
		this.capacidad = capacidad;
		this.cantidadInscriptos = cantidadInscriptos;
		this.dniProfesor=dniProfesor;
	}
	
	
	//METODOS:
	public String getMateria() {
		return materia;
	}

	public Integer getIdCicloLectivo() {
		return idCicloLectivo;
	}

	public String getTurno() {
		return turno;
	}

	public String getDia() {
		return dia;
	}
	
	public Integer getIdComision() {
		return idComision;
	}
	
	public Integer getCapacidad() {
		return capacidad;
	}

	public Integer getCantidadInscriptos() {
		return cantidadInscriptos;
	}
	
	public Integer getIdAula() {
		return idAula;
	}

	public Integer getDniProfesor() {
		return dniProfesor;
	}

	public void setAgregarInscripto() {
		this.cantidadInscriptos ++;
	}
	
	
	
}
